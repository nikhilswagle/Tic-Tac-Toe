'''
Created on Sep 22, 2010
@author: Damodar P. Shenvi Wagle
Tic Tac Toe
'''

class Options(object):
    '''
        Stores the options for the game
    '''
    
    __userSymbol = None
    __userTurn = None
    __cpuSymbol = None
    __cpuTurn = None

    def __init__(self):
        '''
            Sets the options for the game
        '''
        pass
    
    def setUserSymbol(self,symbolId):
        Options.__userSymbol = self.symbolMapping()[symbolId]
    
    def getUserSymbol(self):
        return Options.__userSymbol
    
    def setUserTurn(self,turnId):
        Options.__userTurn = self.orderMapping()[turnId]
        
    def getUserTurn(self):
        return Options.__userTurn
    
    def setCPUSymbol(self,symbolId):
        if(symbolId == 0):
            Options.__cpuSymbol = self.symbolMapping()[1]
        else:
            Options.__cpuSymbol = self.symbolMapping()[0]
        
    def getCPUSymbol(self):
        return Options.__cpuSymbol
    
    def setCPUTurn(self,turnId):
        if(turnId == 0):
            Options.__cpuTurn = self.orderMapping()[1]
        else:  
            Options.__cpuTurn = self.orderMapping()[0]
            
    def getCPUTurn(self):
        return Options.__cpuTurn
    
    def symbolMapping(self):
        """
            Maps id to symbol value
        """
        return {0:"X",1:"O"}
    
    def orderMapping(self):
        """
            Maps id to order value
        """
        return {0:1,1:2}
    