Instructions

1) The application has been developed using "wxPython" the GUI library for python. Thus you will need that library in order to run the program.
2) "mainAppl.py" should be run to start the application.
3) This zip file does not contain the executable for playing Tic Tac Toe. I will put it shortly.
