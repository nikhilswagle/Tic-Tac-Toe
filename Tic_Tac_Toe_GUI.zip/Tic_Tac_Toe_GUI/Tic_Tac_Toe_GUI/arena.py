'''
Created on Sep 22, 2010
@author: Damodar P. Shenvi Wagle
Tic Tac Toe
'''
import wx
from algorithm import Algorithm
from options import Options
from time import sleep
from changeSettings import ChangeSettingsWizard

class Arena(wx.Frame):
    '''
        Top level frame that holds all the widgets.
    '''
    
    def __init__(self, parent=None, title="Tic Tac Toe"):
        '''
            Constructor
        '''
        wx.Frame.__init__(self, parent=parent, title=title,size=(300,300)) 
        
        # save option instance
        self.options = Options()
        
        # Create an instance of Algorithm class
        self.alg = Algorithm(self.options)
        
        # Keep track of number of moves
        self.move = 0
        
        # Create a panel
        self.panel = wx.Panel(self)
        
        # Set initial list of values
        self.listOfVal = ["1","2","3","4","5","6","7","8","9"]
        self.initialMap = {1:"1",2:"2",3:"3",4:"4",5:"5",6:"6",7:"7",8:"8",9:"9"}
        
        # First create controls
        self.createControls()
        
        # Create a main sizer (box sizer) that will hold the options.
        mainSizer = wx.BoxSizer(wx.VERTICAL)
        mainSizer.Add((10,10),proportion=0,flag=wx.EXPAND)
        mainSizer.Add(self.heading, 0, wx.CENTER, 5)
        mainSizer.Add((10,10),proportion=0,flag=wx.EXPAND)
        mainSizer.Add(wx.StaticLine(self.panel), 0, wx.EXPAND|wx.TOP|wx.BOTTOM, 5)
        mainSizer.Add((10,10),proportion=0,flag=wx.EXPAND)
        
        # gridSizer is a Grid Bag Sizer that holds Tic Tac Toe Map.
        gridSizer = wx.GridBagSizer(hgap=10,vgap=10)
        #gridSizer.AddGrowableCol(1)
        self.map = {}
        i=0
        j=0
        pos=1
        for val in self.listOfVal:
            txt = wx.StaticText(self.panel, -1, val)
            txt.SetFont(wx.Font(15, wx.SWISS, wx.NORMAL, wx.NORMAL))
            gridSizer.Add(txt, pos=(i,j), flag=wx.ALIGN_CENTER)
            j=j+1
            if(j<4):
                #gridSizer.Add((5,5), pos=(i,j), flag=wx.ALIGN_CENTER)
                gridSizer.Add(wx.StaticLine(self.panel,style=wx.LI_VERTICAL),
                              pos=(i,j),span=(1,1),flag=wx.EXPAND|wx.ALIGN_CENTER)
            j=j+1
            if(j%6 == 0):
                j=0
                i=i+1
                if(i<4):
                    gridSizer.Add(wx.StaticLine(self.panel), pos=(i,j), span=(1,6),
                                  flag=wx.EXPAND|wx.ALIGN_CENTER)
                i=i+1
            self.map[pos] = txt
            pos = pos + 1
        
        
        
        # now add the gridSizer to the mainSizer
        mainSizer.Add(gridSizer, proportion=0, flag=wx.CENTER, border=10)    
        mainSizer.Add((10,10),proportion=0,flag=wx.EXPAND)
        mainSizer.Add(wx.StaticLine(self.panel), 0, wx.EXPAND|wx.TOP|wx.BOTTOM, 5)
        mainSizer.Add((10,10),proportion=0,flag=wx.EXPAND)
        
        # Add position choice box to the mainSizer
        posSizer = wx.BoxSizer(wx.HORIZONTAL)
        posSizer.Add(self.posLbl, wx.EXPAND)
        posSizer.Add((20,20))
        posSizer.Add(self.posChoice, wx.EXPAND)
        posSizer.Add((20,20))
        posSizer.Add(self.playBtn)
        
        mainSizer.Add(posSizer, proportion=0, flag=wx.CENTER, border=10)
        mainSizer.Add((10,10),proportion=0,flag=wx.EXPAND)
        mainSizer.Add(wx.StaticLine(self.panel), 0, wx.EXPAND|wx.TOP|wx.BOTTOM, 5)
        mainSizer.Add((10,10),proportion=0,flag=wx.EXPAND)
        
        # Add buttons to the btnSizer
        btnSizer = wx.BoxSizer(wx.HORIZONTAL)
        btnSizer.Add(self.changeSettingBtn, wx.EXPAND)
        btnSizer.Add((20,20))
        btnSizer.Add(self.resetBtn, wx.EXPAND)
        
        # Add btnSizer to the mainSizer
        mainSizer.Add(btnSizer, proportion=0, flag=wx.CENTER, border=10)
        mainSizer.Add((10,10),proportion=0,flag=wx.EXPAND)
        
        self.panel.SetSizer(mainSizer)
        mainSizer.Fit(self)
        mainSizer.SetSizeHints(self)
    
        
    
    def createControls(self):
        """
            Creates controls for connections wizard. 
        """
        # Title.
        self.heading = wx.StaticText(self.panel, -1, "Tic Tac Toe")
        self.heading.SetFont(wx.Font(18, wx.SWISS, wx.NORMAL, wx.BOLD))
        
        # Position Label
        self.posLbl = wx.StaticText(self.panel, -1, "Enter the position for X or O")
        
        # Position choice box to enter position for X or O
        self.choiceList = ["1","2","3","4","5","6","7","8","9"]
        self.posChoice = wx.Choice(self.panel, -1,choices=self.choiceList,name="position")
        #self.Bind(wx.EVT_CHOICE, self.onPosition, self.posChoice)
        
        # Start Button
        self.changeSettingBtn = wx.Button(self.panel, -1, "Change Settings")
        self.Bind(wx.EVT_BUTTON, self.onChangeSetting, self.changeSettingBtn)
        
        # Play Button
        self.playBtn = wx.Button(self.panel, -1, "Play")
        self.Bind(wx.EVT_BUTTON, self.onPlay, self.playBtn)
        
        # Reset Button
        self.resetBtn = wx.Button(self.panel,wx.ID_RESET,"Reset")
        self.Bind(wx.EVT_BUTTON, self.onReset, self.resetBtn)
        
    
    def onPlay(self,event):
        """
            Run the algorithm to get the best available position. 
        """
        if(self.posChoice.GetStringSelection()):
            
            # Update the map at the user entered position
            self.move = self.move + 1
            pos = int(self.posChoice.GetStringSelection())
            
            # Update map and choice list
            self.updateMap(pos,self.options.getUserSymbol())
            self.updateChoiceList(str(pos))
                    
            # Trigger CPU
            self.triggerCPU(pos)
        else:
            message = "Please select a position !!!"
            caption = "Notice"
            self.displayMessage(message, caption)
        
    def onReset(self,event):
        """
            Reset all the values of the map
        """
        self.refresh()
        self.options = Options()
        if(self.options.getCPUTurn() == 1):
            self.triggerCPU(None)
        else:
            message = "Please start the game by selecting a position to play."
            caption = "Notice"
            self.displayMessage(message, caption)     
        
    def onChangeSetting(self,event):
        """
            Changes the game settings.
        """
        chngSet = ChangeSettingsWizard(self)
        chngSet.CenterOnScreen()
        chngSet.Show()
    
    def triggerCPU(self,pos):
        """
            Start CPU's turn
        """
        # Detect the win for user and then find the new position if required. 
        self.alg.updateMap(self.map)
        self.alg.updatePos(pos)
        if(self.alg.checkForWin()):
            message = "Congratulations You Win !!!\n"+\
                      "Click Reset button to start a new game."
            caption = "Win"
            # Put some delay before displaying message.
            sleep(1) #sleeps for 1 seconds
            self.displayMessage(message, caption)
            self.refresh()
        elif(self.move == 9):
            message = "Its a Draw !!!\n"+\
                      "Click Reset button to start a new game."
            caption = "Draw"
            # Put some delay before displaying message.
            sleep(1) #sleeps for 1 seconds
            self.displayMessage(message, caption)
            self.refresh()
        else:            
            # Run the algorithm and get the best available position.
            self.move = self.move + 1
            self.alg.updateMove(self.move)
            newPos = self.alg.findNewPosition()
            
            # Put some delay before updating map.
            sleep(1) #sleeps for 1 seconds
            
            # Update the map and choice list
            self.updateMap(newPos,self.options.getCPUSymbol()) 
            self.updateChoiceList(str(newPos))
            
            # Detect win for cpu after updating the map with new position found. 
            self.alg.updateMap(self.map)
            self.alg.updatePos(newPos)
            self.alg.updateMove(self.move) 
            if(self.alg.checkForWin()):
                message = "Sorry You Lost !!!\n"+\
                          "Click Reset button to start a new game."
                caption = "Loose"
                # Put some delay before displaying message.
                sleep(1) #sleeps for 1 seconds
                self.displayMessage(message, caption)
                self.refresh()
            else:
                if(self.move == 9):
                    message = "Its a Draw !!!\n"+\
                              "Click Reset button to start a new game."
                    caption = "Draw"
                    # Put some delay before displaying message.
                    sleep(1) #sleeps for 1 seconds
                    self.displayMessage(message, caption)
                    self.refresh()
        
    def updateChoiceList(self,pos):
        # Update the choice list
        self.choiceList.remove(pos)
        self.posChoice.SetItems(self.choiceList)
        
    def updateMap(self,pos,val):
        """
            Updates the map at the given position with given values
        """
        self.map[pos].SetLabel(val)
        
    def displayMessage(self,message,caption):
        '''
            Displays message in a message dialog.
        '''
        dlg = wx.MessageDialog(self, message,caption,style=wx.OK,
                               pos=wx.DefaultPosition)
        dlg.ShowModal()
        
    def refresh(self):
        """
            Refreshes all the values of the map
        """
        keys = self.map.keys()
        for key in keys:
            self.map[key].SetLabel(self.initialMap[key])
        self.choiceList = ["1","2","3","4","5","6","7","8","9"]
        self.posChoice.SetItems(self.choiceList)
        self.move = 0
        
        
        
        