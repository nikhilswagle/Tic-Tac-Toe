'''
Created on Sep 22, 2010
@author: Damodar P. Shenvi Wagle
Tic Tac Toe
'''

import wx
from arena import Arena
from options import Options

class OptionWizard(wx.Frame):
    '''
        Provides user with initial options.
    '''

    def __init__(self):
        '''
            Constructor for option frame.
        '''
        
        wx.Frame.__init__(self, parent=None, id=-1, title='Options', 
                          size=(350, 200))
        self.panel = wx.Panel(self, -1)        
               
        # Create controls
        self.createControls()
        
        # Create a main sizer (box sizer) that will hold the options.
        mainSizer = wx.BoxSizer(wx.VERTICAL)
        mainSizer.Add((10,10),proportion=0,flag=wx.EXPAND)
        mainSizer.Add(self.heading, 0, wx.CENTER, 5)
        mainSizer.Add((10,10),proportion=0,flag=wx.EXPAND)
        mainSizer.Add(wx.StaticLine(self.panel), 0, wx.EXPAND|wx.TOP|wx.BOTTOM, 5)
        mainSizer.Add((10,10),proportion=0,flag=wx.EXPAND)
        mainSizer.Add(self.symbolOption,proportion=0,flag=wx.EXPAND)
        mainSizer.Add((10,10),proportion=0,flag=wx.EXPAND)
        mainSizer.Add(self.orderOption,proportion=0,flag=wx.EXPAND)
        mainSizer.Add((10,10),proportion=0,flag=wx.EXPAND)
        mainSizer.Add(wx.StaticLine(self.panel), 0, wx.EXPAND|wx.TOP|wx.BOTTOM, 5)
        mainSizer.Add((10,10),proportion=0,flag=wx.EXPAND)
        
        # Add buttons to the btnSizer
        btnSizer = wx.BoxSizer(wx.HORIZONTAL)
        btnSizer.Add(self.setOptionsBtn, wx.EXPAND)
        
        # Add btnSizer to the mainSizer
        mainSizer.Add(btnSizer, proportion=0, flag=wx.CENTER, border=10)
        mainSizer.Add((10,10),proportion=0,flag=wx.EXPAND)
        self.panel.SetSizer(mainSizer)
        mainSizer.Fit(self)
        mainSizer.SetSizeHints(self)
        
    def createControls(self):
        """
            Creates controls.
        """
        # Radio box for options
        symbolList = ["X","O"]
        self.symbolOption = wx.RadioBox(self.panel, -1, "Select Symbol", 
                                        (10, 10), wx.DefaultSize,
                                        symbolList, 2, wx.RA_SPECIFY_COLS)
        self.symbolOption.SetSelection(0)
        orderList = ["Play First","Play Second"]
        self.orderOption = wx.RadioBox(self.panel, -1, "Select Order",
                                       (10, 10), wx.DefaultSize,
                                       orderList, 2, wx.RA_SPECIFY_COLS)
        self.orderOption.SetSelection(0)
        
        # Heading.
        self.heading = wx.StaticText(self.panel, -1, "Choose the following options")
        self.heading.SetFont(wx.Font(15, wx.SWISS, wx.NORMAL, wx.BOLD))
        
        # Start Button
        self.setOptionsBtn = wx.Button(self.panel, -1, "Set Options")
        self.Bind(wx.EVT_BUTTON, self.onSetOptions, self.setOptionsBtn)
        
    def onSetOptions(self,event):
        """
            Get the parameters and go to arena where the actual game is played.
        """
        symbol = self.symbolOption.GetSelection()
        turn = self.orderOption.GetSelection()
        opt = Options()
        opt.setUserSymbol(symbol)
        opt.setUserTurn(turn)
        opt.setCPUSymbol(symbol)
        opt.setCPUTurn(turn)
        arena = Arena()
        arena.CenterOnScreen()
        arena.Show()
        self.Close()
        if(opt.getCPUTurn() == 1):
            arena.triggerCPU(None)
        else:
            message = "Please start the game by selecting a position."
            caption = "Notice"
            dlg = wx.MessageDialog(self, message,caption,style=wx.OK,
                                   pos=wx.DefaultPosition)
            dlg.ShowModal()
        
        
    
    
        
        
        
        