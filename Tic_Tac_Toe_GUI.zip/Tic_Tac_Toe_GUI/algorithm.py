'''
Created on Sep 22, 2010
@author: Damodar P. Shenvi Wagle
Tic Tac Toe
'''

import random

class Algorithm(object):
    '''
        Implements the logic for calculating the best position available
    '''
    __cornerPosList = [1,3,7,9]
    __edgePosList = [2,4,6,8]
    __centerPos = 5
    __posMap = [[1,2,3],[4,5,6],[7,8,9]]
    __defaultVal = ["1","2","3","4","5","6","7","8","9"]
    
    def __init__(self,options=None):
        '''
        Constructor
        '''
        self.map = None
        self.pos = 1
        self.move = 2
        self.options = options  
        
    def updateMap(self,map):
        self.map = map
        
    def updatePos(self,pos):
        self.pos = pos
        
    def updateMove(self,move):
        self.move = move
    
    def findNewPosition(self):
        if(self.move == 1):
            return self.firstMove()
        elif(self.move == 2):
            return self.secondMove(self.pos)
        else:
            return self.nextMove(self.map,self.pos)
            
    def firstMove(self):
        '''
            Calculates the position for the opening move
        '''
        return random.choice(Algorithm.__cornerPosList)
    
    def secondMove(self,pos):
        '''
            Calculates the position for the opening move
        '''
        #print "second move"
        if(Algorithm.__cornerPosList.__contains__(pos)):
            #print "center"
            return Algorithm.__centerPos
        elif(pos == Algorithm.__centerPos):
            #print "corner"
            return random.choice(Algorithm.__cornerPosList)
        elif(Algorithm.__edgePosList.__contains__(pos)):
            #print "edge"
            rand = random.randint(1,3)
            if(rand == 1):
                return Algorithm.__centerPos
            elif(rand == 2):
                return random.choice([pos-1,pos+1])
            else:
                return self.calculateOpposite(pos)
    
    def nextMove(self,map,pos):
        '''
            Calculates next best position.
        '''
        # Win: If the player has two in a row, play the third to get three in a row.
        pos = self.checkForWinPosition(self.options.getCPUSymbol())
        if(pos):
            #print "win position for cpu"
            #print pos
            return pos
        else:
            # Block: If the opponent has two in a row, play the third to block them.
            pos = self.checkForWinPosition(self.options.getUserSymbol())
            if(pos):
                #print "win position for user"
                #print pos
                return pos
            else:
                #Fork: Create an opportunity where you can win in two ways.
                pos = self.detectFork(self.options.getCPUSymbol())
                if(pos):
                    #print "fork position for cpu"
                    #print pos
                    return pos
                else: 
                    # Block Fork of the opponent by detecting a specific pattern.
                    pos = self.checkForSpecificPattern()
                    if(pos):
                        #print "Fork position for user"
                        #print pos
                        return pos
                    else:
                        # Block Fork of the opponent.
                        pos = self.detectFork(self.options.getUserSymbol())
                        if(pos):
                            #print "fork position for user"
                            #print pos
                            return pos
                        else: 
                            # Check if center position is free.
                            pos = self.checkCenterPos()
                            if(pos):
                                #print "Center position"
                                #print pos
                                return pos
                            else:
                                # Check if the opponent is in the corner and play in the middle of that row or column
                                pos = self.checkForCornerOpponent()
                                if(pos):
                                    #print "Corner opponent found"
                                    #print pos
                                    return pos
                                else:
                                    # Check for empty corner
                                    pos = self.checkEmptyCorner()
                                    if(pos):
                                        #print "Empty corner"
                                        #print pos
                                        return pos
                                    else:
                                        # Check for empty side
                                        #print "Empty side"
                                        #print pos
                                        pos = self.checkEmptySide()
                                        return pos
    
    def calculateOpposite(self,pos):
        '''
            Calculates an edge position opposite of pos. 
        '''
        if(pos == 2):
            return 8
        elif(pos == 8):
            return 2
        elif(pos == 4):
            return 6
        elif(pos == 6):
            return 4
        
    def checkForWin(self):
        '''
            Check if an triplet exists in the map and return True if it exists or
            False if it does not exist. 
        '''
        # Check Rows
        for i in range(len(Algorithm.__posMap)):
            j=0
            a = self.map[Algorithm.__posMap[i][j]].GetLabel()
            b = self.map[Algorithm.__posMap[i][j+1]].GetLabel()
            c = self.map[Algorithm.__posMap[i][j+2]].GetLabel()
            if(a == b and a == c):
                return True
        
        # Check Columns
        for j in range(len(Algorithm.__posMap)):
            i=0
            a = self.map[Algorithm.__posMap[i][j]].GetLabel()
            b = self.map[Algorithm.__posMap[i+1][j]].GetLabel()
            c = self.map[Algorithm.__posMap[i+2][j]].GetLabel()
            if(a == b and a == c):
                return True
        
        # Check Cross
        i=0
        j=0
        a = self.map[Algorithm.__posMap[i][j]].GetLabel()
        b = self.map[Algorithm.__posMap[i+1][j+1]].GetLabel()
        c = self.map[Algorithm.__posMap[i+2][j+2]].GetLabel()
        if(a == b and a == c):
            return True
            
        i=0
        j=2
        a = self.map[Algorithm.__posMap[i][j]].GetLabel()
        b = self.map[Algorithm.__posMap[i+1][j-1]].GetLabel()
        c = self.map[Algorithm.__posMap[i+2][j-2]].GetLabel()
        if(a == b and a == c):
            return True
            
    
    def checkForWinPosition(self,symbol):
        '''
            Check if there exists the third position in a row/column/cross which 
            can be filled by cpu such that cpu wins the game. Or Also checks if there 
            exists the third position in a row/column/cross which can be filled by
            user such that user wins. Depends on the symbol we provide as the argument.
        '''
        # Check Rows
        for x in range(len(Algorithm.__posMap)):
            k=3
            for i in range(2):
                for j in range(i+1,3):
                    k=k-1
                    a = self.map[Algorithm.__posMap[x][i]].GetLabel()
                    b = self.map[Algorithm.__posMap[x][j]].GetLabel()
                    c = self.map[Algorithm.__posMap[x][k]].GetLabel()
                    if(a == b and a == symbol and Algorithm.__defaultVal.__contains__(c)):
                        return Algorithm.__posMap[x][k]     
                    
        # Check Columns
        for x in range(len(Algorithm.__posMap)):
            k=3
            for i in range(2):
                for j in range(i+1,3):
                    k=k-1
                    a = self.map[Algorithm.__posMap[i][x]].GetLabel()
                    b = self.map[Algorithm.__posMap[j][x]].GetLabel()
                    c = self.map[Algorithm.__posMap[k][x]].GetLabel()
                    if(a == b and a == symbol and Algorithm.__defaultVal.__contains__(c)):
                        return Algorithm.__posMap[k][x]                        
                    
        # Check Cross
        k=2
        for i in range(2):
            for j in range(i+1,3):
                a = self.map[Algorithm.__posMap[i][i]].GetLabel()
                b = self.map[Algorithm.__posMap[j][j]].GetLabel()
                c = self.map[Algorithm.__posMap[k][k]].GetLabel()
                if(a == b and a == symbol and Algorithm.__defaultVal.__contains__(c)):
                    return Algorithm.__posMap[k][k]
                k=k-1
        
        k=2
        for i in range(2):
            for j in range(i+1,3):
                a = self.map[Algorithm.__posMap[i][2-i]].GetLabel()
                b = self.map[Algorithm.__posMap[j][2-j]].GetLabel()
                c = self.map[Algorithm.__posMap[k][2-k]].GetLabel()
                if(a == b and a == symbol and Algorithm.__defaultVal.__contains__(c)):
                    return Algorithm.__posMap[k][2-k]
                k=k-1
        
        return None
    
    def checkForSpecificPattern(self):
        '''
            Checks for specific pattern where user symbols are in the opposite
            corners and the cpu symbol is in the center.
        '''
        userSymbol = self.options.getUserSymbol()
        cpuSymbol = self.options.getCPUSymbol()
        c1 = self.map[Algorithm.__posMap[0][0]].GetLabel()
        c2 = self.map[Algorithm.__posMap[2][2]].GetLabel()
        c3 = self.map[Algorithm.__posMap[0][2]].GetLabel()
        c4 = self.map[Algorithm.__posMap[2][0]].GetLabel()
        x = self.map[Algorithm.__posMap[1][1]].GetLabel()
                    
        if(((c1==c2 and c1==userSymbol) or (c3==c4 and c4==userSymbol)) and x==cpuSymbol):
            a = Algorithm.__posMap[1][0]
            b = Algorithm.__posMap[1][2]
            c = Algorithm.__posMap[0][1]
            d = Algorithm.__posMap[2][1]
            li = [a,b,c,d]
            for pos in li:
                if(not Algorithm.__defaultVal.__contains__(self.map[pos].GetLabel())):
                    li.remove(pos)
            if(len(li) == 0):
                return None
            else:
                return random.choice(li)
        else:
            return None
    
    def detectFork(self,symbol):
        '''
            Create a fork for wining in two ways.
            Find a position filling which puts the opponent in a situation where
            he/she has one chance but two positions to fill to avoid loosing the game.  
        '''       
        for i in range(3):
            for j in range(3):
                val = self.map[Algorithm.__posMap[i][j]].GetLabel()
                if(Algorithm.__defaultVal.__contains__(val)):
                    if(Algorithm.__posMap[i][j] == Algorithm.__centerPos):
                        pos = self.__detectCenterFork(i,j,symbol)
                        if(pos):
                            return pos
            
                    elif(Algorithm.__cornerPosList.__contains__(Algorithm.__posMap[i][j])):
                        pos = self.__detectCornerFork(i,j,symbol)
                        if(pos):
                            return pos
                    else:
                        pos = self.__detectEdgeFork(i,j,symbol)
                        if(pos):
                            return pos
        return None
    
    def __detectCenterFork(self,i,j,symbol):
        # If center position then check if this can be a fork position.
        l = self.map[Algorithm.__posMap[i][j-1]].GetLabel()
        r = self.map[Algorithm.__posMap[i][j+1]].GetLabel()
        if((l==symbol and Algorithm.__defaultVal.__contains__(r)) or
           (r==symbol and Algorithm.__defaultVal.__contains__(l))):
            path1 = True
        else:
            path1 = False
            
        u = self.map[Algorithm.__posMap[i-1][j]].GetLabel()
        d = self.map[Algorithm.__posMap[i+1][j]].GetLabel()
        if((u==symbol and Algorithm.__defaultVal.__contains__(d)) or
           (d==symbol and Algorithm.__defaultVal.__contains__(u))):
            path2 = True
        else:
            path2 = False
        
        cul = self.map[Algorithm.__posMap[i-1][j-1]].GetLabel()
        cdr = self.map[Algorithm.__posMap[i+1][j+1]].GetLabel()
        if((cul==symbol and Algorithm.__defaultVal.__contains__(cdr)) or
           (cdr==symbol and Algorithm.__defaultVal.__contains__(cul))):
            path3 = True
        else:
            path3 = False
        
        cur = self.map[Algorithm.__posMap[i-1][j+1]].GetLabel()
        cdl = self.map[Algorithm.__posMap[i+1][j-1]].GetLabel()
        if((cur==symbol and Algorithm.__defaultVal.__contains__(cdl)) or
           (cdl==symbol and Algorithm.__defaultVal.__contains__(cur))):
            path4 = True
        else:
            path4 = False
            
        li = [path1,path2,path3,path4]
        for p in range(len(li)-1):
            for q in range(p+1,len(li)):
                if(li[p] and li[q]):
                    return Algorithm.__posMap[i][j]
        return None
            
    def __detectCornerFork(self,i,j,symbol):
        # If corner position then check if this can be a fork position.
        if(i==0):
            # Check col condition
            a = self.map[Algorithm.__posMap[i+1][j]].GetLabel()
            b = self.map[Algorithm.__posMap[i+2][j]].GetLabel()
        else:
            # Check col condition
            a = self.map[Algorithm.__posMap[i-1][j]].GetLabel()
            b = self.map[Algorithm.__posMap[i-2][j]].GetLabel()
        if((a==symbol and Algorithm.__defaultVal.__contains__(b)) or
           (b==symbol and Algorithm.__defaultVal.__contains__(a))):
            path1 = True
        else:
            path1 = False
            
        if(j==0):
            # Check row conditions
            a = self.map[Algorithm.__posMap[i][j+1]].GetLabel()
            b = self.map[Algorithm.__posMap[i][j+2]].GetLabel()
        else:
            # Check row condition
            a = self.map[Algorithm.__posMap[i][j-1]].GetLabel()
            b = self.map[Algorithm.__posMap[i][j-2]].GetLabel()
        if((a==symbol and Algorithm.__defaultVal.__contains__(b)) or
           (b==symbol and Algorithm.__defaultVal.__contains__(a))):
            path2 = True
        else:
            path2 = False
        
        # Check cross conditions.
        if(i==0 and j==0):
            a = self.map[Algorithm.__posMap[i+1][j+1]].GetLabel()
            b = self.map[Algorithm.__posMap[i+2][j+2]].GetLabel()
        elif(i==0 and j==2):
            a = self.map[Algorithm.__posMap[i+1][j-1]].GetLabel()
            b = self.map[Algorithm.__posMap[i+2][j-2]].GetLabel()
        elif(i==2 and j==0):
            a = self.map[Algorithm.__posMap[i-1][j+1]].GetLabel()
            b = self.map[Algorithm.__posMap[i-2][j+2]].GetLabel()
        else:
            a = self.map[Algorithm.__posMap[i-1][j-1]].GetLabel()
            b = self.map[Algorithm.__posMap[i-2][j-2]].GetLabel()
        if((a==symbol and Algorithm.__defaultVal.__contains__(b)) or
           (b==symbol and Algorithm.__defaultVal.__contains__(a))):
            path3 = True
        else:
            path3 = False
        li = [path1,path2,path3]
        for p in range(len(li)-1):
            for q in range(p+1,len(li)):
                if(li[p] and li[q]):
                    return Algorithm.__posMap[i][j]
        return None
        
    def __detectEdgeFork(self,i,j,symbol):
        if(i==0 and j==1):
            # Check row
            a = self.map[Algorithm.__posMap[i][j-1]].GetLabel()
            b = self.map[Algorithm.__posMap[i][j+1]].GetLabel()
            if((a==symbol and Algorithm.__defaultVal.__contains__(b)) or
               (b==symbol and Algorithm.__defaultVal.__contains__(a))):
                path1 = True
            else:
                path1 = False
            
            # Check col
            a = self.map[Algorithm.__posMap[i+1][j]].GetLabel()
            b = self.map[Algorithm.__posMap[i+2][j]].GetLabel()
            if((a==symbol and Algorithm.__defaultVal.__contains__(b)) or
               (b==symbol and Algorithm.__defaultVal.__contains__(a))):
                path2 = True
            else:
                path2 = False
            
        elif(i==1 and j==0):
            # Check row
            a = self.map[Algorithm.__posMap[i][j+1]].GetLabel()
            b = self.map[Algorithm.__posMap[i][j+2]].GetLabel()
            if((a==symbol and Algorithm.__defaultVal.__contains__(b)) or
               (b==symbol and Algorithm.__defaultVal.__contains__(a))):
                path1 = True
            else:
                path1 = False
            
            # Check col
            a = self.map[Algorithm.__posMap[i-1][j]].GetLabel()
            b = self.map[Algorithm.__posMap[i+1][j]].GetLabel()
            if((a==symbol and Algorithm.__defaultVal.__contains__(b)) or
               (b==symbol and Algorithm.__defaultVal.__contains__(a))):
                path2 = True
            else:
                path2 = False
                
        elif(i==1 and j==2):
            # Check row
            a = self.map[Algorithm.__posMap[i][j-1]].GetLabel()
            b = self.map[Algorithm.__posMap[i][j-2]].GetLabel()
            if((a==symbol and Algorithm.__defaultVal.__contains__(b)) or
               (b==symbol and Algorithm.__defaultVal.__contains__(a))):
                path1 = True
            else:
                path1 = False
            
            # Check col
            a = self.map[Algorithm.__posMap[i-1][j]].GetLabel()
            b = self.map[Algorithm.__posMap[i+1][j]].GetLabel()
            if((a==symbol and Algorithm.__defaultVal.__contains__(b)) or
               (b==symbol and Algorithm.__defaultVal.__contains__(a))):
                path2 = True
            else:
                path2 = False
        else:
            # Check row
            a = self.map[Algorithm.__posMap[i][j-1]].GetLabel()
            b = self.map[Algorithm.__posMap[i][j+1]].GetLabel()
            if((a==symbol and Algorithm.__defaultVal.__contains__(b)) or
               (b==symbol and Algorithm.__defaultVal.__contains__(a))):
                path1 = True
            else:
                path1 = False
            
            # Check col
            a = self.map[Algorithm.__posMap[i-1][j]].GetLabel()
            b = self.map[Algorithm.__posMap[i-2][j]].GetLabel()
            if((a==symbol and Algorithm.__defaultVal.__contains__(b)) or
               (b==symbol and Algorithm.__defaultVal.__contains__(a))):
                path2 = True
            else:
                path2 = False
        
        if(path1 and path2):
            return Algorithm.__posMap[i][j]
        else:
            return None
    
    def checkCenterPos(self):
        '''
            Checks if the center position is available.
        '''
        if(Algorithm.__defaultVal.__contains__(Algorithm.__centerPos)):
            return Algorithm.__centerPos()
        else:
            return None
        
    def checkForCornerOpponent(self):
        '''
            Check if the opponent is in the corner and play in the middle of that
            row or column.
        '''
        flag = 0
        for i in range(len(Algorithm.__posMap)):
            for j in range(len(Algorithm.__posMap)):
                if(Algorithm.__posMap[i][j] == self.pos):
                    flag=1
                    break
            if(flag==1):
                break
        
        if(Algorithm.__cornerPosList.__contains__(self.pos)):
            li = []
            if(i==0 and j==0):
                if(Algorithm.__defaultVal.__contains__(Algorithm.__posMap[i+1][j])):
                    li.append(Algorithm.__posMap[i+1][j])
                elif(Algorithm.__defaultVal.__contains__(Algorithm.__posMap[i][j+1])):
                    li.append(Algorithm.__posMap[i][j+1])
            elif(i==0 and j==2):
                if(Algorithm.__defaultVal.__contains__(Algorithm.__posMap[i+1][j])):
                    li.append(Algorithm.__posMap[i+1][j])
                elif(Algorithm.__defaultVal.__contains__(Algorithm.__posMap[i][j-1])):
                    li.append(Algorithm.__posMap[i][j-1])
            elif(i==2 and j==0):
                if(Algorithm.__defaultVal.__contains__(Algorithm.__posMap[i-1][j])):
                    li.append(Algorithm.__posMap[i-1][j])
                elif(Algorithm.__defaultVal.__contains__(Algorithm.__posMap[i][j+1])):
                    li.append(Algorithm.__posMap[i][j+1])
            else:
                if(Algorithm.__defaultVal.__contains__(Algorithm.__posMap[i-1][j])):
                    li.append(Algorithm.__posMap[i-1][j])
                elif(Algorithm.__defaultVal.__contains__(Algorithm.__posMap[i][j-1])):
                    li.append(Algorithm.__posMap[i][j-1])
            if(len(li)==0):
                return None
            else:
                return random.choice(li)
        else:
            return None
            
    def checkEmptyCorner(self):
        '''
             Checks for an empty corner.
        '''
        for corPos in Algorithm.__cornerPosList:
            if(Algorithm.__defaultVal.__contains__(self.map[corPos].GetLabel())):
                return corPos
        return None
    
    def checkEmptySide(self):
        '''
            Checks for an empty side.
        '''
        for sidePos in Algorithm.__edgePosList:
            if(Algorithm.__defaultVal.__contains__(self.map[sidePos].GetLabel())):
                return sidePos
        
        
        
        
        
        
        