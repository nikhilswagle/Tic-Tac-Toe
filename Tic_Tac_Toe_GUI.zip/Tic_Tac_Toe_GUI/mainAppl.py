'''
Created on Sep 22, 2010
@author: Damodar P. Shenvi Wagle
Tic Tac Toe
'''

import wx
from optionWizard import OptionWizard

class mainAppl(wx.App):
    '''
    classdocs
    '''
    
    def OnInit(self):
        '''
            Initializing method. Used to connect to the database when the application starts.
        '''
        return True

if __name__ == '__main__':
    app = mainAppl()
    opt = OptionWizard()
    opt.CenterOnScreen()
    opt.Show()    
    app.MainLoop()
        